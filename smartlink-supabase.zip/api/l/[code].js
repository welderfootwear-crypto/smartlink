import { supabase } from "../../lib/supabase.js";

export default async function handler(req, res) {
  const { code } = req.query;

  const { data, error } = await supabase
    .from("links")
    .select("*")
    .eq("code", code)
    .single();

  if (error || !data) {
    return res.status(404).json({ error: "Link not found" });
  }

  await supabase
    .from("links")
    .update({ clicks: (data.clicks || 0) + 1 })
    .eq("code", code);

  res.writeHead(302, { Location: data.url });
  res.end();
}
