import { supabase } from "../../lib/supabase.js";

export default async function handler(req, res) {
  const { code } = req.query;

  const { data, error } = await supabase
    .from("links")
    .select("*")
    .eq("code", code)
    .single();

  if (error || !data) {
    return res.status(404).json({ error: "Not found" });
  }

  res.status(200).json(data);
}
